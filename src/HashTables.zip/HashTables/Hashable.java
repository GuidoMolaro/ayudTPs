package HashTables;

interface Hashable {
    int hash(int M);
}
