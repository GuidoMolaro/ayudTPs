package HashTables;

public class IsEmptyException extends Exception {
    public IsEmptyException(){
        super();
    }
}
