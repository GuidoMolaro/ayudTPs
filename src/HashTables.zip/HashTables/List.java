package HashTables;

public interface List <L> extends GeneralList<L> {
    void insertNext(L o);
    void insertPrev(L o);
}
